import Foundation

struct RemoteCertificateManifest: Codable {
    let name: String
    let p12URL: String
    let provisionURL: String
    let password: String
    let status: String?
}

@MainActor
final class ESignStore: ObservableObject {
    @Published var unsignedIPAs: [ImportedIPA] = []
    @Published var signedIPAs: [ImportedIPA] = []
    @Published var certificates: [SigningCertificatePair] = []
    @Published var selectedCertificateID: UUID?
    @Published var repositories: [ESignRepoManifest] = []
    @Published var statusLogs: [String] = []
    @Published var isBusy: Bool = false

    let documentsURL: URL
    let certsDirectory: URL
    let unsignedDirectory: URL
    let signedDirectory: URL

    init() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        self.documentsURL = docs
        self.certsDirectory = docs.appendingPathComponent("Certificates", isDirectory: true)
        self.unsignedDirectory = docs.appendingPathComponent("UnsignedIPAs", isDirectory: true)
        self.signedDirectory = docs.appendingPathComponent("SignedIPAs", isDirectory: true)

        try? FileManager.default.createDirectory(at: certsDirectory, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: unsignedDirectory, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: signedDirectory, withIntermediateDirectories: true)

        loadStoredState()
    }

    func log(_ message: String) {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        let entry = "[\(formatter.string(from: Date()))] \(message)"
        statusLogs.append(entry)
    }

    func handleIncomingURL(_ url: URL) {
        let ext = url.pathExtension.lowercased()
        if ext == "ipa" {
            importIPAFile(from: url)
        } else {
            log("Открыт внешний URL: \(url.absoluteString)")
        }
    }

    func importIPAFile(from sourceURL: URL) {
        let accessed = sourceURL.startAccessingSecurityScopedResource()
        defer { if accessed { sourceURL.stopAccessingSecurityScopedResource() } }

        let destURL = unsignedDirectory.appendingPathComponent(sourceURL.lastPathComponent)
        do {
            if FileManager.default.fileExists(atPath: destURL.path) {
                try FileManager.default.removeItem(at: destURL)
            }
            try FileManager.default.copyItem(at: sourceURL, to: destURL)
            let attrs = try FileManager.default.attributesOfItem(atPath: destURL.path)
            let size = (attrs[.size] as? Int64) ?? 0

            let metadata = IPASignerService.shared.inspectIPA(at: destURL)
            let item = ImportedIPA(
                fileName: destURL.lastPathComponent,
                appName: metadata.appName,
                bundleIdentifier: metadata.bundleId,
                version: metadata.version,
                fileSize: size,
                localPath: destURL.path,
                isSigned: false
            )
            unsignedIPAs.insert(item, at: 0)
            saveStoredState()
            log("Импортирован IPA: \(item.appName) (\(item.bundleIdentifier)) v\(item.version)")
        } catch {
            log("Ошибка импорта IPA: \(error.localizedDescription)")
        }
    }

    func importCertificate(p12URL: URL, provisionURL: URL, password: String, alias: String) {
        let p12Access = p12URL.startAccessingSecurityScopedResource()
        let provAccess = provisionURL.startAccessingSecurityScopedResource()
        defer {
            if p12Access { p12URL.stopAccessingSecurityScopedResource() }
            if provAccess { provisionURL.stopAccessingSecurityScopedResource() }
        }

        let id = UUID()
        let p12Dest = certsDirectory.appendingPathComponent("\(id.uuidString).p12")
        let provDest = certsDirectory.appendingPathComponent("\(id.uuidString).mobileprovision")

        do {
            try FileManager.default.copyItem(at: p12URL, to: p12Dest)
            try FileManager.default.copyItem(at: provisionURL, to: provDest)

            let parsed = Self.parseMobileProvision(at: provDest)
            let cert = SigningCertificatePair(
                id: id,
                displayName: alias.isEmpty ? parsed.teamName : alias,
                teamName: parsed.teamName,
                bundleIdWildcard: parsed.appIdName,
                p12Filename: p12Dest.lastPathComponent,
                provisionFilename: provDest.lastPathComponent,
                password: password,
                expirationDate: parsed.expirationDate
            )
            certificates.append(cert)
            if selectedCertificateID == nil {
                selectedCertificateID = cert.id
            }
            saveStoredState()
            log("Добавлен сертификат: \(cert.displayName) (до \(cert.expirationDate.formatted(date: .abbreviated, time: .omitted)))")
        } catch {
            log("Ошибка импорта сертификата: \(error.localizedDescription)")
        }
    }

    func fetchCloudCertificates(from urlString: String = "https://raw.githubusercontent.com/Guf1kSlit1yCoder/Hi-ujj/main/certificates.json") async {
        guard let url = URL(string: urlString) else {
            log("Некорректный адрес облачного источника сертификатов")
            return
        }
        isBusy = true
        defer { isBusy = false }
        log("Проверка облачных сертификатов AltroBOX...")
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let items = try JSONDecoder().decode([RemoteCertificateManifest].self, from: data)
            guard let activeCert = items.first(where: { ($0.status ?? "active").lowercased() == "active" }) ?? items.first else {
                log("В облачном источнике нет доступных сертификатов")
                return
            }

            log("Загрузка сертификата: \(activeCert.name)...")
            guard let p12DownloadURL = URL(string: activeCert.p12URL),
                  let provDownloadURL = URL(string: activeCert.provisionURL) else {
                log("Некорректные ссылки на файлы сертификата")
                return
            }

            let (p12Data, _) = try await URLSession.shared.data(from: p12DownloadURL)
            let (provData, _) = try await URLSession.shared.data(from: provDownloadURL)

            let id = UUID()
            let p12Dest = certsDirectory.appendingPathComponent("\(id.uuidString).p12")
            let provDest = certsDirectory.appendingPathComponent("\(id.uuidString).mobileprovision")

            try p12Data.write(to: p12Dest)
            try provData.write(to: provDest)

            let parsed = Self.parseMobileProvision(at: provDest)
            let cert = SigningCertificatePair(
                id: id,
                displayName: activeCert.name,
                teamName: parsed.teamName,
                bundleIdWildcard: parsed.appIdName,
                p12Filename: p12Dest.lastPathComponent,
                provisionFilename: provDest.lastPathComponent,
                password: activeCert.password,
                expirationDate: parsed.expirationDate
            )

            certificates.removeAll(where: { $0.displayName == cert.displayName })
            certificates.insert(cert, at: 0)
            selectedCertificateID = cert.id
            saveStoredState()
            log("Успешно получен облачный сертификат: \(cert.displayName)")
        } catch {
            log("Ошибка загрузки сертификата: \(error.localizedDescription)")
        }
    }

    static func parseMobileProvision(at url: URL) -> (teamName: String, appIdName: String, expirationDate: Date) {
        guard let data = try? Data(contentsOf: url),
              let content = String(data: data, encoding: .isoLatin1),
              let startRange = content.range(of: "<?xml"),
              let endRange = content.range(of: "</plist>") else {
            return ("Apple Developer Certificate", "*", Date().addingTimeInterval(86400 * 365))
        }
        let plistSlice = String(content[startRange.lowerBound..<endRange.upperBound])
        guard let plistData = plistSlice.data(using: .utf8),
              let dict = try? PropertyListSerialization.propertyList(from: plistData, format: nil) as? [String: Any] else {
            return ("Apple Developer Certificate", "*", Date().addingTimeInterval(86400 * 365))
        }
        let teamName = (dict["TeamName"] as? String) ?? (dict["AppIDName"] as? String) ?? "Developer Certificate"
        let appIdName = (dict["AppIDName"] as? String) ?? "*"
        let expiration = (dict["ExpirationDate"] as? Date) ?? Date().addingTimeInterval(86400 * 365)
        return (teamName, appIdName, expiration)
    }

    func saveStoredState() {
        if let data = try? JSONEncoder().encode(unsignedIPAs) {
            UserDefaults.standard.set(data, forKey: "esign.unsignedIPAs")
        }
        if let data = try? JSONEncoder().encode(signedIPAs) {
            UserDefaults.standard.set(data, forKey: "esign.signedIPAs")
        }
        if let data = try? JSONEncoder().encode(certificates) {
            UserDefaults.standard.set(data, forKey: "esign.certificates")
        }
    }

    func loadStoredState() {
        if let data = UserDefaults.standard.data(forKey: "esign.unsignedIPAs"),
           let items = try? JSONDecoder().decode([ImportedIPA].self, from: data) {
            unsignedIPAs = items
        }
        if let data = UserDefaults.standard.data(forKey: "esign.signedIPAs"),
           let items = try? JSONDecoder().decode([ImportedIPA].self, from: data) {
            signedIPAs = items
        }
        if let data = UserDefaults.standard.data(forKey: "esign.certificates"),
           let items = try? JSONDecoder().decode([SigningCertificatePair].self, from: data) {
            certificates = items
            selectedCertificateID = items.first?.id
        }
    }
}
