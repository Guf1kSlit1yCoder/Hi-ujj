import SwiftUI

struct SignConfigView: View {
    @EnvironmentObject var store: ESignStore
    @Environment(\.dismiss) private var dismiss

    let ipa: ImportedIPA
    @State private var config = SigningConfiguration()
    @State private var isSigning = false
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            Form {
                Section("Параметры приложения") {
                    TextField("Имя приложения", text: $config.customAppName)
                    TextField("Bundle Identifier", text: $config.customBundleId)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    TextField("Версия", text: $config.customVersion)
                }

                Section("Сертификат подписи (.p12 + .mobileprovision)") {
                    if store.certificates.isEmpty {
                        Text("Сертификаты не добавлены. Перейдите на вкладку «Настройки» и импортируйте .p12 и .mobileprovision.")
                            .font(.caption)
                            .foregroundStyle(.red)
                    } else {
                        Picker("Сертификат", selection: $store.selectedCertificateID) {
                            ForEach(store.certificates) { cert in
                                Text("\(cert.displayName) (\(cert.teamName))")
                                    .tag(Optional(cert.id))
                            }
                        }
                    }
                }

                Section("Опции модификации") {
                    Toggle("Открыть доступ к папке Documents в «Файлах»", isOn: $config.enableFileSharing)
                    Toggle("Снять ограничение минимальной версии iOS", isOn: $config.removeMinimumOSCheck)
                    Toggle("Установить сразу после подписи", isOn: $config.installImmediatelyAfterSigning)
                }

                if let errorMessage {
                    Section {
                        Text(errorMessage)
                            .foregroundStyle(.red)
                            .font(.caption)
                    }
                }

                Section {
                    Button {
                        runSignProcess()
                    } label: {
                        HStack {
                            Spacer()
                            if isSigning {
                                ProgressView()
                                    .padding(.trailing, 8)
                                Text("Подпись IPA...")
                            } else {
                                Label("Подписать IPA", systemImage: "checkmark.seal.fill")
                                    .font(.headline)
                            }
                            Spacer()
                        }
                    }
                    .disabled(isSigning || store.certificates.isEmpty)
                }
            }
            .navigationTitle("Подпись \(ipa.appName)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
            }
            .onAppear {
                config.customAppName = ipa.appName
                config.customBundleId = ipa.bundleIdentifier
                config.customVersion = ipa.version
            }
        }
    }

    private func runSignProcess() {
        guard let certID = store.selectedCertificateID ?? store.certificates.first?.id,
              let cert = store.certificates.first(where: { $0.id == certID }) else {
            errorMessage = "Выберите действительный сертификат."
            return
        }
        isSigning = true
        errorMessage = nil

        Task {
            do {
                let signed = try await IPASignerService.shared.signIPA(
                    sourceIPA: ipa,
                    certificate: cert,
                    certsDir: store.certsDirectory,
                    signedOutputDir: store.signedDirectory,
                    config: config
                ) { msg in
                    Task { @MainActor in store.log(msg) }
                }
                store.signedIPAs.insert(signed, at: 0)
                store.saveStoredState()
                isSigning = false
                if config.installImmediatelyAfterSigning {
                    OTAInstallerService.shared.triggerOTAInstall(for: signed, store: store)
                }
                dismiss()
            } catch {
                errorMessage = error.localizedDescription
                store.log("Ошибка подписи: \(error.localizedDescription)")
                isSigning = false
            }
        }
    }
}
