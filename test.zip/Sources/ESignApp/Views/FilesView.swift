import SwiftUI
import UniformTypeIdentifiers

struct FilesView: View {
    @EnvironmentObject var store: ESignStore
    @State private var showFileImporter = false

    var body: some View {
        NavigationStack {
            List {
                Section("Импортированные IPA (Без подписи)") {
                    if store.unsignedIPAs.isEmpty {
                        ContentUnavailableView(
                            "Нет импортированных файлов",
                            systemImage: "arrow.down.doc",
                            description: Text("Нажмите «+» в правом верхнем углу, чтобы импортировать .ipa файл из приложения «Файлы».")
                        )
                    } else {
                        ForEach(store.unsignedIPAs) { ipa in
                            HStack(spacing: 12) {
                                Image(systemName: "shippingbox.fill")
                                    .font(.title2)
                                    .foregroundStyle(.blue)
                                    .frame(width: 40, height: 40)
                                    .background(Color.blue.opacity(0.12))
                                    .clipShape(RoundedRectangle(cornerRadius: 10))

                                VStack(alignment: .leading, spacing: 3) {
                                    Text(ipa.appName)
                                        .font(.headline)
                                    Text("\(ipa.bundleIdentifier) • v\(ipa.version)")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                    Text(ByteCountFormatter.string(fromByteCount: ipa.fileSize, countStyle: .file))
                                        .font(.caption2)
                                        .foregroundStyle(.tertiary)
                                }
                                Spacer()
                            }
                        }
                        .onDelete { offsets in
                            store.unsignedIPAs.remove(atOffsets: offsets)
                            store.saveStoredState()
                        }
                    }
                }

                if !store.statusLogs.isEmpty {
                    Section("Журнал событий (Logs)") {
                        ForEach(store.statusLogs.suffix(8), id: \.self) { entry in
                            Text(entry)
                                .font(.system(.caption, design: .monospaced))
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("Файлы")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showFileImporter = true
                    } label: {
                        Label("Импорт IPA", systemImage: "plus.circle.fill")
                    }
                }
            }
            .fileImporter(
                isPresented: $showFileImporter,
                allowedContentTypes: [UTType(filenameExtension: "ipa") ?? .data, .archive],
                allowsMultipleSelection: true
            ) { result in
                if case .success(let urls) = result {
                    for url in urls {
                        store.importIPAFile(from: url)
                    }
                }
            }
        }
    }
}
