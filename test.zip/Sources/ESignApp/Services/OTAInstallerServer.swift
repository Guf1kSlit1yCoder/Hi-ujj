import Foundation
import UIKit

/// Generates an OTA `manifest.plist` and triggers `itms-services://` installation on-device.
@MainActor
final class OTAInstallerService {
    static let shared = OTAInstallerService()
    private init() {}

    var localHTTPSPort: UInt16 = 8443
    var localDomain: String = "127.0.0.1.backloop.dev"

    func generateInstallManifest(for signedIPA: ImportedIPA, ipaDownloadURL: String) -> Data? {
        let manifest: [String: Any] = [
            "items": [
                [
                    "assets": [
                        [
                            "kind": "software-package",
                            "url": ipaDownloadURL
                        ]
                    ],
                    "metadata": [
                        "bundle-identifier": signedIPA.bundleIdentifier,
                        "bundle-version": signedIPA.version,
                        "kind": "software",
                        "title": signedIPA.appName
                    ]
                ]
            ]
        ]
        return try? PropertyListSerialization.data(fromPropertyList: manifest, format: .xml, options: 0)
    }

    func triggerOTAInstall(for signedIPA: ImportedIPA, store: ESignStore) {
        let ipaURL = URL(fileURLWithPath: signedIPA.localPath)
        guard FileManager.default.fileExists(atPath: ipaURL.path) else {
            store.log("Ошибка установки: файл \(signedIPA.fileName) не найден")
            return
        }

        let manifestEndpoint = "https://\(localDomain):\(localHTTPSPort)/install/manifest.plist?id=\(signedIPA.id.uuidString)"
        guard let encodedURL = manifestEndpoint.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let itmsURL = URL(string: "itms-services://?action=download-manifest&url=\(encodedURL)") else {
            store.log("Не удалось сформировать ссылку itms-services://")
            return
        }

        store.log("Запуск системной установки iOS (itms-services) для \(signedIPA.appName)...")
        UIApplication.shared.open(itmsURL)
    }
}
