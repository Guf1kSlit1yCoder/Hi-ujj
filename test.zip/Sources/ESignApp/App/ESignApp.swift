import SwiftUI

@main
struct ESignApp: App {
    @StateObject private var store = ESignStore()

    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(store)
                .onOpenURL { url in
                    store.handleIncomingURL(url)
                }
        }
    }
}
